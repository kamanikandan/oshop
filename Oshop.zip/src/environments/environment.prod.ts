export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBWqe4ZKv9sxDJub0nNLOYZyK7uPTd04pI",
    authDomain: "oshop-8e129.firebaseapp.com",
    databaseURL: "https://oshop-8e129.firebaseio.com",
    projectId: "oshop-8e129",
    storageBucket: "oshop-8e129.appspot.com",
    messagingSenderId: "838911652263"
  }
};
